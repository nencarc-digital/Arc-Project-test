**************
About Lectures
**************

TBD